import Parser from "rss-parser";
import { SOURCES } from "./pipeline/sources";
const p = new Parser({ timeout: 12000, headers: { "User-Agent": "LawCA-Bot/1.0" } });
(async () => {
  const rows = await Promise.all(SOURCES.map(async (s) => { try { const f = await p.parseURL(s.url); return `✓ ${s.id.padEnd(12)} ${String(f.items.length).padStart(3)} items  ${s.url}`; } catch (e) { return `✗ ${s.id.padEnd(12)} ${(e as Error).message.slice(0, 60)}  ${s.url}`; } }));
  console.log(rows.join("\n"));
})();
